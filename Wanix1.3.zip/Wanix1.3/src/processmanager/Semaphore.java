package processmanager;

import java.util.*;

public class Semaphore {
	private String name;
	private int value;// �ź���ֵ
	private ArrayList<Process> queue = new ArrayList<Process>();// ������������

	public String getName() {
		return name;
	}

	public Semaphore(String name, int value) {
		this.name = name;
		if (value >= 0)
			this.value = value;
	}

	public void P(Process p) throws Exception {
		value--;
		if (value < 0) {
			queue.add(p);
			ProcessController.getProcessController().block();
			System.out.println("Process " + p.pcb.getName() + " is blocked by semaphore " + name);
		} else {
			System.out.println("Process " + p.pcb.getName() + " went through semaphore " + name);
		}
	}

	public void V() {
		value++;
		if (value <= 0) {
			Process p = queue.get(0);
			queue.remove(0);
			ProcessController.wake(p.pcb.getId());
			System.out.println("Process " + p.pcb.getName() + " is waken up by semaphore " + name);
		} else {
			System.out.println("Increased semaphore " + name);
		}
	}
}
