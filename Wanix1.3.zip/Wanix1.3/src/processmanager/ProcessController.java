package processmanager;

import java.util.*;

import filemanager.File;
import memorymanager.MemoryController;
import memorymanager.MemoryControllerFF;
import userinterface.MemoryControllerInterface;

public class ProcessController implements Runnable {
	private static List<Process> block_queue = null;
	private static List<Process> ready_queue = null;
	private static Process runningProcess = null;

	private static long timeSlice;
	private MemoryController mr = MemoryControllerFF.getInstance();
	private static ProcessController processController = null;

	private ProcessController() {
		block_queue = new ArrayList<Process>();
		ready_queue = new ArrayList<Process>();
		runningProcess = null;
		timeSlice = 1;
	}

	public static long getTimeSlice() {
		return timeSlice;
	}

	public static ProcessController getProcessController() {
		if (processController == null)
			processController = new ProcessController();
		return processController;
	}

	public boolean create(Process proc) {
		boolean flag;
		if (flag = mr.allocation(proc))
			ready_queue.add(proc);
		// mr.display();
		return flag;
	}

	public boolean ready() throws Exception {
		if (runningProcess != null) {
			runningProcess.pcb.setState(PCB.READY);
			ProcessController.ready_queue.add(runningProcess);
			runningProcess = null;
		}
		while (ready_queue.size() == 0 && runningProcess == null) {
			Thread.sleep(1);
		}
		runningProcess = ready_queue.get(0);
		ready_queue.remove(0);
		runningProcess.pcb.setState(PCB.RUN);
		return true;
	}

	public boolean block() throws Exception {
		block_queue.add(runningProcess);
		runningProcess.pcb.setState(PCB.BLOCK);
		runningProcess = null;
		return true;
	}

	public boolean remove() throws Exception {
		for (File f : runningProcess.pcb.getFiles()) {
			f.getInode().setP(null);
		}
		mr.release(runningProcess);
		if (ready_queue.size() == 0) {
			runningProcess = null;
		} else {
			runningProcess = ready_queue.get(0);
			ready_queue.remove(0);
		}
		// mr.display();
		return true;
	}

	public static boolean wake(long id) {
		Iterator<Process> it = block_queue.iterator();
		int index = 0;
		while (it.hasNext()) {
			Process cur = it.next();
			if (cur.pcb.getId() == id)
				break;
			index++;
		}
		if (index == block_queue.size()) {
			return false;
		}
		Process p = block_queue.get(index);
		block_queue.remove(index);
		ready_queue.add(p);
		p.pcb.setState(PCB.READY);
		return true;
	}

	public static void schedule() throws Exception {
		while (true) {
			while (ready_queue.isEmpty() && runningProcess == null) {
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			try {
				ProcessController.getProcessController().ready();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			runningProcess.run();
			MemoryControllerInterface.getInstance().updateProcessControllerInterface();
		}
	}

	public static Process getRunningProcess() {
		return runningProcess;
	}
	
	public static List<Process> getBlock_queue() {
		return block_queue;
	}

	public static List<Process> getReady_queue() {
		return ready_queue;
	}


	@Override
	public void run() {
		try {
			schedule();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
