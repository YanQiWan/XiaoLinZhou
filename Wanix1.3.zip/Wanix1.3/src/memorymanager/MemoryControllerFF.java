package memorymanager;

import java.util.*;
import processmanager.Process;

public class MemoryControllerFF extends MemoryController {
	private static MemoryControllerFF memoryControllerFF=null;
	
	private MemoryControllerFF()
	{
		super();
	}
	public static MemoryControllerFF getInstance()
	{
		if(memoryControllerFF==null)
			memoryControllerFF=new MemoryControllerFF();
		return memoryControllerFF;
	}
	public boolean allocation(Process p) {
		long psize = p.pcb.getSize();
		ListIterator<PartitionItem> it = partition_table.listIterator();
		while (it.hasNext()) {
			int index = it.nextIndex();
			PartitionItem curitem = it.next();
			if (curitem.isEmpty() && curitem.getSize() >= psize) {
				curitem.setP(p);
				remaintotal -= psize;
				long remain = curitem.getSize() - psize;
				if (remain != 0) {
					curitem.setSize(psize);
					PartitionItem newItem = new PartitionItem();
					newItem.setSize(remain);
					newItem.setStartAddress(curitem.getStartAddress() + psize);
					partition_table.add(index + 1, newItem);
				}
				return true;
			}
		}
		if (remaintotal >= psize) {
			it = partition_table.listIterator();
			long empty = 0, occupied = 0;
			int index = 0;
			while (empty < psize) {
				PartitionItem curitem = it.next();
				if (curitem.isEmpty()) {
					empty += curitem.getSize();
					partition_table.remove(curitem);
				} else {
					curitem.setStartAddress(occupied);
					occupied += curitem.getSize();
					index++;
				}
			}
			PartitionItem newItem = new PartitionItem();
			newItem.setStartAddress(occupied);
			newItem.setSize(psize);
			newItem.setP(p);

			partition_table.add(index, newItem);
			if (empty != psize) {
				newItem = new PartitionItem();
				newItem.setStartAddress(occupied + psize);
				newItem.setSize(empty - psize);
				partition_table.add(index + 1, newItem);
			}
			return true;
		} else {
			System.out.println("Failed to allocate:" + p.pcb.getName());
			return false;
		}
	}
}
