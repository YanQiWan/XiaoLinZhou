package commonality;

public class User implements java.io.Serializable {
	private int UserId;
	private String PhoneNumber;
	private String Passwd;
	private int score;
	private String NickName;
	private int age;

	public int getUserId() {
		return UserId;
	}

	public void setUserId(int userId) {
		UserId = userId;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getPasswd() {
		return Passwd;
	}

	public void setPasswd(String passwd) {
		Passwd = passwd;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getNickName() {
		return NickName;
	}

	public void setNickName(String nickName) {
		NickName = nickName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public User(String number, String Passwd) {
		this.PhoneNumber = number;
		this.Passwd = Passwd;
	}

	public User(String number, String Passwd, String NickName, int age) {
		this(number, Passwd);
		this.NickName = NickName;
		this.age = age;
	}
}
