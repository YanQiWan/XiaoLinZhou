package commonality;

@SuppressWarnings("serial")
public class TransportObject implements java.io.Serializable {
	public static final int login = 1;
	public static final int regist = 2;
	public static final int get_friend_list = 3;
	private Object object;
	private int servicetype;

	public TransportObject(int servicetype, Object object) {
		this.object = object;
		this.servicetype = servicetype;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}

	public int getServicetype() {
		return servicetype;
	}

	public void setServicetype(int servicetype) {
		this.servicetype = servicetype;
	}
}
