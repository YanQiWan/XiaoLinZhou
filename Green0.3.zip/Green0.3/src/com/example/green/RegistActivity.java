package com.example.green;

import com.example.green.R;
import commonality.User;
import connectiontools.InternetConnection;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View.OnClickListener;

public class RegistActivity extends Activity {
	private EditText et_PhoneNumber;
	private EditText et_Passwd;
	private EditText et_NickName;
	private EditText et_Age;
	private Button bt_regist;
	private Button bt_return;
	CalThread calThread;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_regist);
		et_PhoneNumber = (EditText) findViewById(R.id.et_PhoneNumber);
		et_Passwd = (EditText) findViewById(R.id.et_Passwd);
		et_NickName = (EditText) findViewById(R.id.et_NickName);
		et_Age = (EditText) findViewById(R.id.et_age);
		bt_return = (Button) findViewById(R.id.bt_return);
		bt_return.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent_return = new Intent(RegistActivity.this, LoginActivity.class);
				startActivity(intent_return);
			}
		});
		bt_regist = (Button) findViewById(R.id.bt_regist);
		bt_regist.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder = new AlertDialog.Builder(RegistActivity.this).setTitle("ע���˺�")
						.setIcon(R.drawable.ic_launcher).setMessage("ȷ��Ҫע���˺���");
				setPositiveButton(builder);
				setNegativeButton(builder).create().show();
			}
		});
	}

	private AlertDialog.Builder setPositiveButton(AlertDialog.Builder builder) {
		return builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				calThread = new CalThread();
				calThread.start();
			}
		});
	}

	private AlertDialog.Builder setNegativeButton(AlertDialog.Builder builder) {
		return builder.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {

			}
		});
	}

	class CalThread extends Thread {
		@SuppressLint("SimpleDateFormat")
		public void run() {
			Looper.prepare();
			User changed_user = new User(et_PhoneNumber.getText().toString().trim(),
					et_Passwd.getText().toString().trim(), et_NickName.getText().toString().trim(),
					Integer.valueOf(et_Age.getText().toString()));
			int UserId = -1;
			try {
				UserId = InternetConnection.getInstance().RegistInformation(changed_user);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (UserId != -1) {
				changed_user.setUserId(UserId);
				LoginActivity.login_user = changed_user;
				Intent intent = new Intent(RegistActivity.this, MainActivity.class);
				startActivity(intent);
			} else
				Toast.makeText(RegistActivity.this, "�˺�ע��ʧ��", Toast.LENGTH_SHORT).show();
			Looper.loop();
		}
	};
}
