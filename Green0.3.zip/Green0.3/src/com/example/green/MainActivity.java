package com.example.green;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.example.green.R;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.design.widget.TabLayout.OnTabSelectedListener;
import android.support.design.widget.TabLayout.Tab;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.KeyEvent;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends FragmentActivity {
	// TabLayout
	private TabLayout mTabLayout;
	// ViewPager
	private ViewPager mViewPager;
	// Title
	private List<String> mTitle;
	// Fragment
	private List<Fragment> mFragment;
	public static File database;// ���ݿ��ļ�

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// this.requestWindowFeature(Window.FEATURE_NO_TITLE);//ȥ��������
		setContentView(R.layout.activity_main);
		initData();
		initView();
		// database=initdatabase();
	}

	/*
	 * ��ʼ������
	 */
	private void initData() {

		mTitle = new ArrayList<String>();
		mTitle.add("�ҵ���Ϣ");
		mTitle.add(" �� ҳ");
		mTitle.add(" �� ��");

		mFragment = new ArrayList<Fragment>();
		mFragment.add(new UserFragment());
		mFragment.add(new HomapageFragment());
		mFragment.add(new FriendFragment());
		// DatabaseQuery.CollegeMkdirs();//���������ļ���Ŀ¼
	}

	/*
	 * ��ʼ��view
	 */
	private void initView() {
		mTabLayout = (TabLayout) findViewById(R.id.mTabLayout);
		mViewPager = (ViewPager) findViewById(R.id.mViewPager);

		mViewPager.setOffscreenPageLimit(mTabLayout.getTabCount());

		// mViewPager
		mViewPager.addOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				mTabLayout.getTabAt(arg0).select();
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub

			}
		});

		// ����������
		MyFragmentPagerAdapter myFragmentPagerAdapter = new MyFragmentPagerAdapter(getSupportFragmentManager(),
				mFragment, mTitle, this);
		mViewPager.setAdapter(myFragmentPagerAdapter);
		mTabLayout.setupWithViewPager(mViewPager);
		for (int i = 0; i < mTabLayout.getTabCount(); i++) {
			mTabLayout.getTabAt(i).setCustomView(myFragmentPagerAdapter.getTabView(i));
		}
		mTabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

			@SuppressWarnings("deprecation")
			@Override
			public void onTabUnselected(Tab tab) {
				// TODO Auto-generated method stub
				switch (tab.getPosition()) {
				case 0:
					tab.getCustomView().findViewById(R.id.item_picutre).setBackgroundResource(R.drawable.personal_black);
					break;
				case 1:
					tab.getCustomView().findViewById(R.id.item_picutre).setBackgroundResource(R.drawable.homepage_black);
					break;
				case 2:
					tab.getCustomView().findViewById(R.id.item_picutre).setBackgroundResource(R.drawable.friendlist_black);
					break;
				}
				TextView textView = (TextView) tab.getCustomView().findViewById(R.id.item_text);
				textView.setTextColor(getResources().getColor(R.color.colorAccent));
			}

			@SuppressWarnings("deprecation")
			@Override
			public void onTabSelected(Tab tab) {
				// TODO Auto-generated method stub
				switch (tab.getPosition()) {
				case 0:
					tab.getCustomView().findViewById(R.id.item_picutre).setBackgroundResource(R.drawable.personal_green);
					break;
				case 1:
					tab.getCustomView().findViewById(R.id.item_picutre).setBackgroundResource(R.drawable.homepage_green);
					break;
				case 2:
					tab.getCustomView().findViewById(R.id.item_picutre).setBackgroundResource(R.drawable.friendlist_green);
					break;
				}
				TextView textView = (TextView) tab.getCustomView().findViewById(R.id.item_text);
				textView.setTextColor(getResources().getColor(R.color.colorSelected));
				mViewPager.setCurrentItem(tab.getPosition());
			}

			@Override
			public void onTabReselected(Tab arg0) {
				// TODO Auto-generated method stub

			}
		});
		mViewPager.setCurrentItem(1);
		mTabLayout.getTabAt(1).select();
	}
	double exitTime = 0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
			if ((System.currentTimeMillis() - exitTime) > 2000) // System.currentTimeMillis()���ۺ�ʱ���ã��϶�����2000
			{
				Toast.makeText(getApplicationContext(), "�ٰ�һ���˳�����", Toast.LENGTH_SHORT).show();
				exitTime = System.currentTimeMillis();
			} else {
				Intent MyIntent = new Intent(Intent.ACTION_MAIN); 
				MyIntent.addCategory(Intent.CATEGORY_HOME); 
				startActivity(MyIntent); 
				android.os.Process.killProcess(android.os.Process.myPid());
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	// �����ݿ���ص��ֻ���
	/*
	 * private File initdatabase() { File file=getDatabasePath("school.db");
	 * if(!file.exists()) { file.getParentFile().mkdirs(); } else { return file;
	 * } BufferedInputStream bufferedInputStream = null; BufferedOutputStream
	 * bufferedOutputStream=null; try { bufferedInputStream=new
	 * BufferedInputStream(getAssets().open("school.db"));
	 * bufferedOutputStream=new BufferedOutputStream(new
	 * FileOutputStream(file)); byte[] buffer=new byte[8192]; int len=0;
	 * while((len=bufferedInputStream.read(buffer))!=-1) {
	 * bufferedOutputStream.write(buffer,0,len); } bufferedOutputStream.flush();
	 * return file; } catch (IOException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); }finally{ try { if(bufferedInputStream!=null)
	 * bufferedInputStream.close(); if(bufferedOutputStream!=null)
	 * bufferedOutputStream.close(); } catch (IOException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } } return null; }
	 */

}
