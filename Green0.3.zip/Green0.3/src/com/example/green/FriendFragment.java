package com.example.green;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Looper;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import commonality.User;
import android.widget.AdapterView.OnItemClickListener;

public class FriendFragment extends Fragment {
	ListView listView;
	TextView textView;
	// CalThread calThread;

	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.friend_fragment, null);
		listView = (ListView) view.findViewById(R.id.list);
		textView = (TextView) view.findViewById(R.id.path);
		listView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

			}
		});
		return view;
	}
	public void updateFriendList()
	{
		
	}
	private void inflateListView(List<User> friendList)
	{
		List<Map<String,Object>> listItems = new ArrayList<Map<String,Object>>();
		for(int i=0;i<friendList.size();i++)
		{
			/*Map<String,Object> listItem = new HashMap<String,Object>();
			listItem.put("rank", i);
			listItem.put("head", friendList.get(i).get);
			listItem.put("score", friendList.get(i).getNickName());
			listItem.put("score", friendList.get(i).getScore());
			listItems.add(listItem);*/
		}
		SimpleAdapter simpleAdapter = new SimpleAdapter(this.getActivity(),
				listItems,R.layout.friend_list
				,new String[]{"rank","head","name","score","medal"}
				,new int[]{R.id.tv_rank,R.id.iv_head,R.id.tv_name,R.id.tv_score,R.id.iv_medal});
		listView.setAdapter(simpleAdapter);
	}
	/*
	 * class CalThread extends Thread {
	 * 
	 * @SuppressLint("SimpleDateFormat") public void run() { Looper.prepare();
	 * boolean succeed=InternetConnection.FileUpload(new
	 * CFile(LoginActivity.login_user.getUserId(),
	 * currentFiles[file_position].getName(),SubjectName,currentFiles[
	 * file_position])); if(succeed) { Toast.makeText(getApplication(),
	 * "�ļ��ϴ��ɹ�!", Toast.LENGTH_SHORT).show(); } else {
	 * Toast.makeText(getApplication(), "�ļ��ϴ�ʧ��!", Toast.LENGTH_SHORT).show(); }
	 * Looper.loop(); } };
	 */

}
