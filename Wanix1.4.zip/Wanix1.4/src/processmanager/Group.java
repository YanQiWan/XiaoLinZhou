package processmanager;

public enum Group {
	OTHERS, GROUP, OWNER, SUPER
}
