package commonality;

public interface ServiceType {
	public static final int login = 1;
	public static final int regist = 2;
	public static final int get_friend_list = 3;
	public static final int return_friend_list = 4;
	public static final int log_out = 5;
	public static final int change = 6;
}
