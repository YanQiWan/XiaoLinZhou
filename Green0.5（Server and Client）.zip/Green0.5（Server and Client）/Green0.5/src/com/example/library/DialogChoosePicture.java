package com.example.library;

import com.example.green.R;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class DialogChoosePicture extends Dialog implements android.view.View.OnClickListener {

	private View inflate;
	private TextView choosePhoto;
	private TextView takePhoto;
	private ICustomDialogEventListener onCustomDialogEventListener;

	public interface ICustomDialogEventListener {
		public void customDialogEvent(int valueYouWantToSendBackToTheActivity);
	}

	public DialogChoosePicture(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public DialogChoosePicture(Context context, int id) {
		super(context, id);
		// TODO Auto-generated constructor stub
	}

	// �ڹ��캯���У����ý�ȥ�ص�����
	public DialogChoosePicture(Context context, int id, ICustomDialogEventListener onCustomDialogEventListener) {
		super(context, id);
		this.onCustomDialogEventListener = onCustomDialogEventListener;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		// ���Ի���Ĳ���
		inflate = LayoutInflater.from(getContext()).inflate(R.layout.dialog_bottom, null);

		// ��ʼ���ؼ�
		choosePhoto = (TextView) inflate.findViewById(R.id.choosePhoto);
		takePhoto = (TextView) inflate.findViewById(R.id.takePhoto);
		choosePhoto.setOnClickListener(this);
		takePhoto.setOnClickListener(this);
		// ���������ø�Dialog
		this.setContentView(inflate);
		// ��ȡ��ǰActivity���ڵĴ���
		Window dialogWindow = this.getWindow();
		// ����Dialog�Ӵ���ײ�����
		dialogWindow.setGravity(Gravity.BOTTOM);
		// ��ô��������
		WindowManager.LayoutParams lp = dialogWindow.getAttributes();
		lp.y = 20;// ����Dialog����ײ��ľ���
		// ���������ø�����
		dialogWindow.setAttributes(lp);
		super.onCreate(savedInstanceState);
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.takePhoto:
			Toast.makeText(this.getContext(), "���������", Toast.LENGTH_SHORT).show();
			onCustomDialogEventListener.customDialogEvent(R.id.takePhoto);
			break;
		case R.id.choosePhoto:
			Toast.makeText(this.getContext(), "����˴����ѡ��", Toast.LENGTH_SHORT).show();
			onCustomDialogEventListener.customDialogEvent(R.id.choosePhoto);
			break;
		}
		this.dismiss();
	}

}
