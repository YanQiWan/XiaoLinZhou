package com.example.green;

import com.example.green.R;
import com.example.library.*;
import com.example.library.ActionSheetDialog.SheetItemColor;
import com.example.library.ActionSheetDialog.OnSheetItemClickListener;

import commonality.User;
import connectiontools.InternetConnection;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View.OnClickListener;

public class RegistActivity extends Activity {
	private EditText et_PhoneNumber;
	private EditText et_Passwd;
	private EditText et_NickName;
	private EditText et_Age;
	private Button bt_regist;
	private Button bt_return;
	private CircleImageView civ_head;
	CalThread calThread;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_regist);
		et_PhoneNumber = (EditText) findViewById(R.id.et_PhoneNumber);
		et_Passwd = (EditText) findViewById(R.id.et_Passwd);
		et_NickName = (EditText) findViewById(R.id.et_NickName);
		et_Age = (EditText) findViewById(R.id.et_age);
		bt_return = (Button) findViewById(R.id.bt_return);
		civ_head = (CircleImageView) findViewById(R.id.civ_head);
		civ_head.setBackgroundResource(R.drawable.ic_launcher);
		civ_head.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new ActionSheetDialog(RegistActivity.this).builder().setCancelable(true).setCanceledOnTouchOutside(true)
						.addSheetItem("����", SheetItemColor.Blue, new OnSheetItemClickListener() {
							@Override
							public void onClick(int which) {
								Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
								startActivityForResult(intent, MacroDefinition.TAKE_PHOTO_REQUEST);
							}
						}).addSheetItem("�����ѡ��", SheetItemColor.Blue, new OnSheetItemClickListener() {
							@Override
							public void onClick(int which) {
								pickImageFromAlbum();
							}
						}).show();
			}
		});

		bt_return.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent_return = new Intent(RegistActivity.this, LoginActivity.class);
				startActivity(intent_return);
			}
		});
		bt_regist = (Button) findViewById(R.id.bt_regist);
		bt_regist.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder = new AlertDialog.Builder(RegistActivity.this).setTitle("ע���˺�")
						.setIcon(R.drawable.ic_launcher).setMessage("ȷ��Ҫע���˺���");
				setPositiveButton(builder);
				setNegativeButton(builder).create().show();
			}
		});
	}

	private AlertDialog.Builder setPositiveButton(AlertDialog.Builder builder) {
		return builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				calThread = new CalThread();
				calThread.start();
			}
		});
	}

	private AlertDialog.Builder setNegativeButton(AlertDialog.Builder builder) {
		return builder.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {

			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		switch (requestCode) {
		case MacroDefinition.TAKE_PHOTO_REQUEST:
			if (resultCode == RESULT_CANCELED) {
				Toast.makeText(RegistActivity.this, "ȡ��������", Toast.LENGTH_LONG).show();
				return;
			}
			Bitmap photo = data.getParcelableExtra("data");
			civ_head.setImageBitmap(photo);
			break;
		case MacroDefinition.CHOOSE_PHOTO_REQUEST:
			if (resultCode == RESULT_CANCELED) {
				Toast.makeText(RegistActivity.this, "ȡ����ѡ��", Toast.LENGTH_LONG).show();
				return;
			}
			try {
				Uri imageUri = data.getData();
				Log.e("TAG", imageUri.toString());
				civ_head.setImageURI(imageUri);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}
	}

	// ������ȡ
	public void pickImageFromAlbum() {
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_GET_CONTENT);
		intent.setType("image/*");
		startActivityForResult(intent, MacroDefinition.CHOOSE_PHOTO_REQUEST);
	}

	class CalThread extends Thread {
		@SuppressLint("SimpleDateFormat")
		public void run() {
			Looper.prepare();
			User regist_user = new User(et_PhoneNumber.getText().toString().trim(),
					et_Passwd.getText().toString().trim(), et_NickName.getText().toString().trim(),
					Integer.valueOf(et_Age.getText().toString()));
			regist_user.setHeadimage(MacroDefinition.getPicture(civ_head.getDrawable()));
			try {
				if (InternetConnection.getInstance().RegistInformation(regist_user)) {
					LoginActivity.login_user = regist_user;
					Intent intent = new Intent(RegistActivity.this, MainActivity.class);
					startActivity(intent);
				} else
					Toast.makeText(RegistActivity.this, "�˺�ע��ʧ��", Toast.LENGTH_SHORT).show();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Looper.loop();
		}
	}

}
