package ConnectionTools;

import commonality.*;
import java.net.*;
import java.util.List;
import java.io.*;

public class UserThread implements Runnable {
	private Socket s;
	public boolean exit = false;

	public UserThread(Socket s) {
		this.s = s;
	}

	public Socket getS() {
		return s;
	}

	public void setS(Socket s) {
		this.s = s;
	}

	public void run() {
		while (!exit) {
			try {
				// System.out.println("fuck");
				System.out.println(s.toString());
				ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
				System.out.println("fuck");
				TransportObject get_m = (TransportObject) ois.readObject();

				switch (get_m.getServicetype()) {
				case ServiceType.get_friend_list:
					try {
						List<User> friendlist = DataBaseConnection.GetFriendList(get_m.getSender());
						ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
						TransportObject obj = new TransportObject(ServiceType.return_friend_list, friendlist);
						obj.setObject(friendlist);
						oos.writeObject(obj);
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case ServiceType.log_out:
					String PhoneNumber = get_m.getSender();// Ҫ�����PhoneNumber
					OnLineUserList.getThread(PhoneNumber).exit = true;
					OnLineUserList.removeThread(PhoneNumber);
					System.out.println(PhoneNumber + "�˳��ˣ���������" + OnLineUserList.chatlist.size());
					break;
				case ServiceType.change:
					System.out.println(get_m.getSender() + "�޸�����Ϣ����������");
					int succeed = DataBaseConnection.ChangeInformation(get_m);
					ObjectOutputStream obj = new ObjectOutputStream(s.getOutputStream());
					obj.writeObject(new TransportObject(ServiceType.change, new Integer(succeed)));
					break;
				}
			} catch (Exception e) {

			}
		}
	}
}