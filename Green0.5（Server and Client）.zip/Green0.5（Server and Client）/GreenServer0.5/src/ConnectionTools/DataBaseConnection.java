package ConnectionTools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import commonality.TransportObject;
import commonality.User;

public class DataBaseConnection {
	private static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static String dbURL = "jdbc:sqlserver://localhost:1433;DatabaseName=Green";
	private static String userName = "sa";
	private static String userPwd = "software+2015";
	private static Connection dbConn = null;
	static {
		try {
			Class.forName(driverName);
			System.out.println("���������ɹ���");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("��������ʧ�ܣ�");
		}
		try {
			dbConn = DriverManager.getConnection(dbURL, userName, userPwd);
			System.out.println("�������ݿ�ɹ���");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.print("SQL Server����ʧ�ܣ�");
		}
	}

	public static User Examine(User user) {

		PreparedStatement ps = null;
		User login_user = null;
		String sql = "select * from UserInfo where PhoneNumber=? and Passwd=?";
		try {
			ps = dbConn.prepareStatement(sql);
			ps.setString(1, user.getPhoneNumber());
			ps.setString(2, user.getPasswd());
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				login_user = new User(rs.getString(2), rs.getString(3));
				login_user.setHeadimage(rs.getBytes(4));
				login_user.setScore(rs.getInt(5));
				login_user.setNickName(rs.getString(6));
				login_user.setAge(rs.getInt(7));
				ps.close();
				login_user.setFriendList(GetFriendList(login_user.getPhoneNumber()));
				System.out.println("funccanlogin");
			} else {
				System.out.println("�鲻������");
				ps.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return login_user;
	}

	public static boolean RegistInformation(User user) {
		// TODO Auto-generated method stub
		PreparedStatement ps = null;
		String sql = "insert into UserInfo(PhoneNumber,Passwd,HeadImage,Score,NickName,Age) values(?,?,?,?,?,?)";
		try {
			ps = dbConn.prepareStatement(sql);
			ps.setString(1, user.getPhoneNumber());
			ps.setString(2, user.getPasswd());
			ps.setBytes(3, user.getHeadimage());
			ps.setInt(4, 0);
			ps.setString(5, user.getNickName());
			ps.setInt(6, user.getAge());
			if (ps.executeUpdate() != 0) {
				System.out.println("���ݲ���ɹ�!");
				ps.close();
				return true;
			} else
				System.out.println("���ݲ���ʧ��!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public static int ChangeInformation(TransportObject transportObject) {
		// TODO Auto-generated method stub
		PreparedStatement ps = null;
		User user = (User) transportObject.getObject();
		String sql = "UPDATE UserInfo SET PhoneNumber=?,NickName=?,Passwd=?,HeadImage=?,Age=? WHERE PhoneNumber=?";
		int succeed = 0;
		try {
			ps = dbConn.prepareStatement(sql);
			ps.setString(1, user.getPhoneNumber());
			ps.setString(2, user.getNickName());
			ps.setString(3, user.getPasswd());
			ps.setBytes(4, user.getHeadimage());
			ps.setInt(5, user.getAge());
			ps.setString(6, transportObject.getSender());
			succeed = ps.executeUpdate();
			ps.close();
			if (succeed != 0) {
				System.out.println("�����޸ĳɹ�!" + succeed);
				return succeed;
			} else
				System.out.println("�����޸�ʧ��!" + succeed);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return succeed;
	}

	public static List<User> GetFriendList(String PhoneNumber) {
		PreparedStatement ps = null;
		List<User> friendlist = new ArrayList<User>();
		String sql = "select PhoneNumber,HeadImage,Score,NickName,Age from UserInfo where UserId in (select Friend_Id from FriendShip where UserId=(select UserId from UserInfo where PhoneNumber=?))";
		try {
			ps = dbConn.prepareStatement(sql);
			ps.setString(1, PhoneNumber);
			ResultSet resultset = ps.executeQuery();
			while (resultset.next()) {
				User friend = new User();
				friend.setPhoneNumber(resultset.getString(1));
				;
				friend.setHeadimage(resultset.getBytes(2));
				friend.setScore(resultset.getInt(3));
				friend.setNickName(resultset.getString(4));
				friend.setAge(resultset.getInt(5));
				friendlist.add(friend);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return friendlist;
	}
}
