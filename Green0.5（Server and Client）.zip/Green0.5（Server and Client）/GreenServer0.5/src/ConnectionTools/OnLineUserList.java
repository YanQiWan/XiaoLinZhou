package ConnectionTools;

import java.util.HashMap;

public class OnLineUserList {
	public static HashMap<String, UserThread> chatlist = new HashMap<String, UserThread>();

	public static void addThread(String PhoneNumber, UserThread Thread) {
		chatlist.put(PhoneNumber, Thread);
	}

	public static void removeThread(String PhoneNumber) {
		chatlist.remove(PhoneNumber);
	}

	public static UserThread getThread(String PhoneNumber) {
		return (UserThread) chatlist.get(PhoneNumber);
	}
}
