package ConnectionTools;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import commonality.*;

@SuppressWarnings("serial")
public class InternetConnection implements java.io.Serializable, ServiceType {
	private static InternetConnection internetConnection = null;

	public static InternetConnection getInstance() {
		if (internetConnection == null)
			internetConnection = new InternetConnection();
		return internetConnection;
	}

	private InternetConnection() {
		try {
			@SuppressWarnings("resource")
			ServerSocket serversocket = new ServerSocket(7777);
			while (true) {
				// �ӿͻ��˽�������
				Socket s = serversocket.accept();
				ObjectInputStream in = new ObjectInputStream(s.getInputStream());
				TransportObject transportobj = (TransportObject) in.readObject();
				int type = transportobj.getServicetype();
				ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
				switch (type) {
				case ServiceType.Service.login: {
					User u = (User) transportobj.getObject();
					System.out.println("password=" + u.getPasswd() + "username" + u.getPhoneNumber());
					// ��ͻ��˷�������
					User login_user = DataBaseConnection.Examine(u);
					if (login_user != null) {
						UserThread handlingThread = new UserThread(s);
						handlingThread.exit = false;
						new Thread(handlingThread).start();
						OnLineUserList.addThread(login_user.getPhoneNumber(), handlingThread);
						System.out.println("��������Ϊ:" + OnLineUserList.chatlist.size());
					}
					out.writeObject(login_user);
					break;
				}
				case ServiceType.Service.regist: {
					User u = (User) transportobj.getObject();
					System.out.println("password=" + u.getPasswd() + "username" + u.getPhoneNumber());
					// ��ͻ��˷�������
					boolean flag = DataBaseConnection.RegistInformation(u);
					out.writeObject(flag);
					break;
				}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * private boolean ChangeInformation(User user) { PreparedStatement ps =
	 * null; String sql =
	 * "UPDATE UserInfo SET UserPassword=?,UserNickname=?,UserSchool=?,UserMajor=? WHERE UserNumber=?"
	 * ; try { ps = dbConn.prepareStatement(sql); ps.setString(1,
	 * user.getPassWord()); ps.setString(2, user.getUserNickname());
	 * ps.setString(3, user.getUserSchool()); ps.setString(4,
	 * user.getUserMajor()); ps.setString(5, user.getUserNumber()); int succeed
	 * = ps.executeUpdate(); dbConn.close(); ps.close(); if (succeed != 0) {
	 * System.out.println("�����޸ĳɹ�!"); return true; } else
	 * System.out.println("�����޸�ʧ��!"); } catch (SQLException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } return false; }
	 */

	public static void main(String args[]) {
		System.out.println("�������Ѿ�����\n");
		InternetConnection.getInstance();
	}
}
