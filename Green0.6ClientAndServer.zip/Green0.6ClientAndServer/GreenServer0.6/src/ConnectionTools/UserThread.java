package ConnectionTools;

import commonality.*;
import java.net.*;
import java.util.List;
import java.io.*;

public class UserThread implements Runnable {
	private Socket s;
	public boolean exit = false;

	public UserThread(Socket s) {
		this.s = s;
	}

	public Socket getS() {
		return s;
	}

	public void setS(Socket s) {
		this.s = s;
	}

	public void run() {
		while (!exit) {
			try {
				// System.out.println("fuck");
				System.out.println(s.toString());
				ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
				TransportObject get_m = (TransportObject) ois.readObject();

				switch (get_m.getServicetype()) {
				case ServiceType.Service.get_friend_list:
					try {
						List<User> friendlist = DataBaseConnection.GetFriendList(get_m.getSender());
						ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
						TransportObject obj = new TransportObject(ServiceType.Service.return_friend_list, friendlist);
						obj.setObject(friendlist);
						oos.writeObject(obj);
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case ServiceType.Service.log_out:
					String PhoneNumber = get_m.getSender();// Ҫ�����PhoneNumber
					OnLineUserList.getThread(PhoneNumber).exit = true;
					OnLineUserList.removeThread(PhoneNumber);
					System.out.println(PhoneNumber + "�˳��ˣ���������" + OnLineUserList.chatlist.size());
					break;
				case ServiceType.Service.change:
					System.out.println(get_m.getSender() + "�޸�����Ϣ����������");
					int succeed = DataBaseConnection.ChangeInformation(get_m);
					ObjectOutputStream obj = new ObjectOutputStream(s.getOutputStream());
					obj.writeObject(new TransportObject(ServiceType.Service.change, new Integer(succeed)));
					break;
				case ServiceType.Service.search_friend:
					List<User> search_result = DataBaseConnection.search_friend((String) get_m.getObject());
					ObjectOutputStream obj1 = new ObjectOutputStream(s.getOutputStream());
					System.out.println(ServiceType.Service.search_friend+"   "+search_result.size());
					obj1.writeObject(new TransportObject(ServiceType.Service.search_friend, search_result));
				case ServiceType.Service.add_friend:
					break;
				}
			} catch (Exception e) {

			}
		}
	}
}