package com.example.green;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.example.library.MyFunction;
import com.example.library.SysApplication;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import commonality.User;

public class SearchListActivity extends Activity {
	private ListView listView;
	private Button bt_return;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_searchlist);
		SysApplication.getInstance().addActivity(this);
		inflateListView(AddFriendActivity.search_result);
	}

	public void inflateListView(List<User> friendList) {
		listView = (ListView) findViewById(R.id.list);
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < friendList.size(); i++) {

			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put("HeadImage",
					MyFunction.getPicFromBytes(friendList.get(i).getHeadimage(), new BitmapFactory.Options()));
			listItem.put("NickName", friendList.get(i).getNickName());
			listItem.put("PhoneNumber", friendList.get(i).getPhoneNumber());
			listItems.add(listItem);
		}
		System.out.println(friendList.size());
		SimpleAdapter simpleAdapter = new SimpleAdapter(this, listItems, R.layout.search_friend_item,
				new String[] { "HeadImage", "NickName", "PhoneNumber" },
				new int[] { R.id.civ_HeadIamge, R.id.tv_name, R.id.tv_PhoneNumber });
		listView.setAdapter(simpleAdapter);
		simpleAdapter.setViewBinder(new SimpleAdapter.ViewBinder() {
			@Override
			public boolean setViewValue(View view, Object data, String textRepresentation) {
				// TODO Auto-generated method stub
				if (view instanceof ImageView && data instanceof Bitmap) {
					ImageView iv = (ImageView) view;
					iv.setImageBitmap((Bitmap) data);
					return true;
				} else {
					return false;
				}
			}
		});
		listView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Intent intent = new Intent(SearchListActivity.this, NewFriendActivity.class);
				intent.putExtra("newfriend", AddFriendActivity.search_result.get(position));
				startActivity(intent);
			}
		});

		bt_return = (Button) findViewById(R.id.bt_return);
		bt_return.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}
}
