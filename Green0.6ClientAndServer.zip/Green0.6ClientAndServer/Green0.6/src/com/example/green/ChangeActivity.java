package com.example.green;

import java.io.ObjectOutputStream;
import com.example.green.R;
import com.example.library.*;
import com.example.library.ActionSheetDialog.SheetItemColor;
import com.example.library.ActionSheetDialog.OnSheetItemClickListener;
import commonality.ServiceType;
import commonality.TransportObject;
import commonality.User;
import connectiontools.InternetConnection;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View.OnClickListener;

public class ChangeActivity extends Activity {
	private EditText et_PhoneNumber;
	private EditText et_Passwd;
	private EditText et_NickName;
	private EditText et_Age;
	private Button bt_change;
	private Button bt_return;
	private CircleImageView civ_head;
	public static int state = ServiceType.State.block;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		SysApplication.getInstance().addActivity(this);
		setContentView(R.layout.activity_change);
		state = ServiceType.State.block;
		initView();
	}

	private void initView() {
		et_PhoneNumber = (EditText) findViewById(R.id.et_PhoneNumber);
		et_Passwd = (EditText) findViewById(R.id.et_Passwd);
		et_NickName = (EditText) findViewById(R.id.et_NickName);
		et_Age = (EditText) findViewById(R.id.et_age);
		bt_return = (Button) findViewById(R.id.bt_return);
		civ_head = (CircleImageView) findViewById(R.id.civ_head);
		et_NickName.setText(LoginActivity.login_user.getNickName());
		et_Age.setText(LoginActivity.login_user.getAge() + "");
		et_PhoneNumber.setText(LoginActivity.login_user.getPhoneNumber());
		et_PhoneNumber.setEnabled(false);
		et_Passwd.setText(LoginActivity.login_user.getPasswd());
		if (LoginActivity.login_user.getHeadimage() != null) {
			civ_head.setImageBitmap(
					MyFunction.getPicFromBytes(LoginActivity.login_user.getHeadimage(), new BitmapFactory.Options()));
		} else
			civ_head.setImageResource(R.drawable.ic_launcher);
		civ_head.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new ActionSheetDialog(ChangeActivity.this).builder().setCancelable(true).setCanceledOnTouchOutside(true)
						.addSheetItem("����", SheetItemColor.Blue, new OnSheetItemClickListener() {
							@Override
							public void onClick(int which) {
								Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
								startActivityForResult(intent, MyFunction.TAKE_PHOTO_REQUEST);
							}
						}).addSheetItem("�����ѡ��", SheetItemColor.Blue, new OnSheetItemClickListener() {
							@Override
							public void onClick(int which) {
								pickImageFromAlbum();
							}
						}).show();
			}
		});

		bt_return.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent_return = new Intent(ChangeActivity.this, MainActivity.class);
				startActivity(intent_return);
			}
		});
		bt_change = (Button) findViewById(R.id.bt_change);
		bt_change.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder = new AlertDialog.Builder(ChangeActivity.this).setTitle("�޸���Ϣ")
						.setIcon(R.drawable.ic_launcher).setMessage("ȷ���޸���Ϣ��");
				setPositiveButton(builder);
				setNegativeButton(builder).create().show();
			}
		});
	}

	private AlertDialog.Builder setPositiveButton(AlertDialog.Builder builder) {
		return builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				new Thread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						Looper.prepare();
						User change_user = new User(et_PhoneNumber.getText().toString().trim(),
								et_Passwd.getText().toString().trim(), et_NickName.getText().toString().trim(),
								Integer.valueOf(et_Age.getText().toString()));
						change_user.setHeadimage(MyFunction.getPicture(civ_head.getDrawable()));
						try {
							ObjectOutputStream objectOutputStream = new ObjectOutputStream(
									InternetConnection.socket.getOutputStream());
							TransportObject send_m = new TransportObject(ServiceType.Service.change, change_user);
							send_m.setSender(LoginActivity.login_user.getPhoneNumber());
							objectOutputStream.writeObject(send_m);
							while (state == ServiceType.State.block)
								Thread.sleep(1);
							if (state == ServiceType.State.complete) {
								change_user.setFriendList(LoginActivity.login_user.getFriendList());
								LoginActivity.login_user = change_user;
								Toast.makeText(ChangeActivity.this, "�޸ĳɹ�", Toast.LENGTH_SHORT).show();
							} else
								Toast.makeText(ChangeActivity.this, "�޸�ʧ��", Toast.LENGTH_SHORT).show();
							Intent intent = new Intent();
							intent.setClass(ChangeActivity.this, MainActivity.class);
							startActivity(intent);
							finish();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						Looper.loop();
					}
				}).start();
			}
		});
	}

	private AlertDialog.Builder setNegativeButton(AlertDialog.Builder builder) {
		return builder.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {

			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		switch (requestCode) {
		case MyFunction.TAKE_PHOTO_REQUEST:
			if (resultCode == RESULT_CANCELED) {
				Toast.makeText(ChangeActivity.this, "ȡ��������", Toast.LENGTH_LONG).show();
				return;
			}
			Bitmap photo = data.getParcelableExtra("data");
			civ_head.setImageBitmap(photo);
			break;
		case MyFunction.CHOOSE_PHOTO_REQUEST:
			if (resultCode == RESULT_CANCELED) {
				Toast.makeText(ChangeActivity.this, "ȡ����ѡ��", Toast.LENGTH_LONG).show();
				return;
			}
			try {
				Uri imageUri = data.getData();
				Log.e("TAG", imageUri.toString());
				civ_head.setImageURI(imageUri);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}
	}

	// ������ȡ
	public void pickImageFromAlbum() {
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_GET_CONTENT);
		intent.setType("image/*");
		startActivityForResult(intent, MyFunction.CHOOSE_PHOTO_REQUEST);
	}

}
