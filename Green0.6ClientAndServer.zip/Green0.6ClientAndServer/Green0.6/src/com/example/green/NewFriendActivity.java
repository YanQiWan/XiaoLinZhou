package com.example.green;

import java.io.IOException;
import java.io.ObjectOutputStream;

import com.example.library.CircleImageView;
import com.example.library.MyFunction;
import com.example.library.SysApplication;
import android.app.Activity;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import commonality.ServiceType;
import commonality.TransportObject;
import commonality.User;
import connectiontools.InternetConnection;

public class NewFriendActivity extends Activity {
	private CircleImageView civ_HeadImage;
	private TextView tv_nickname;
	private TextView tv_score;
	private TextView tv_age;
	private TextView tv_place;
	private Button bt_return;
	private Button bt_addfriend;
	private Button bt_chat;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_newfriend);
		SysApplication.getInstance().addActivity(this);
		initView();
	}

	private void initView() {
		civ_HeadImage = (CircleImageView) findViewById(R.id.civ_HeadIamge);
		tv_nickname = (TextView) findViewById(R.id.tv_nickname);
		tv_score = (TextView) findViewById(R.id.tv_score);
		tv_age = (TextView) findViewById(R.id.tv_age);
		tv_place = (TextView) findViewById(R.id.tv_place);
		bt_addfriend = (Button) findViewById(R.id.bt_addfriend);
		bt_chat = (Button) findViewById(R.id.bt_chat);
		Bundle bundle = getIntent().getExtras();
		User newfriend = (User) bundle.get("newfriend");

		civ_HeadImage.setImageBitmap(MyFunction.getPicFromBytes(newfriend.getHeadimage(), new BitmapFactory.Options()));
		tv_nickname.setText(newfriend.getNickName());
		tv_score.setText(newfriend.getScore() + "");
		tv_age.setText(newfriend.getAge() + "");
		tv_place.setText("����  ����");
		bt_addfriend.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(NewFriendActivity.this, "��������Ӻ���", Toast.LENGTH_SHORT).show();
				/*try {
					ObjectOutputStream objectOutputStream = new ObjectOutputStream(InternetConnection.socket.getOutputStream());
					TransportObject transportObject = new TransportObject(ServiceType.Service.add_friend, null);
					transportObject.setSender(LoginActivity.login_user.getPhoneNumber());
					transportObject.setGetter(LoginActivity.login_user.getPhoneNumber());
					objectOutputStream.writeObject(transportObject);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
			}
		});
		bt_chat.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(NewFriendActivity.this, "����˷�������", Toast.LENGTH_SHORT).show();
			}
		});
		bt_return = (Button) findViewById(R.id.bt_return);
		bt_return.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}
}
