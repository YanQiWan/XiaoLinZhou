package com.example.green;

import java.io.ObjectOutputStream;
import java.util.List;
import com.example.library.SysApplication;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import commonality.ServiceType;
import commonality.TransportObject;
import commonality.User;
import connectiontools.InternetConnection;

public class AddFriendActivity extends Activity {
	private EditText et_index;
	private Button bt_addfriend_search;
	public static List<User> search_result = null;
	public static int state;

	public static User friend = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		SysApplication.getInstance().addActivity(this);
		setContentView(R.layout.activity_addfriend);
		initView();
	}

	private void initView() {
		et_index = (EditText) findViewById(R.id.et_index);
		bt_addfriend_search = (Button) findViewById(R.id.bt_addfriend_search);
		bt_addfriend_search.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new Thread(new Runnable() {

					@Override
					public void run() {
						Looper.prepare();
						// TODO Auto-generated method stub
						try {
							state = ServiceType.State.block;
							ObjectOutputStream objectOutputStream = new ObjectOutputStream(
									InternetConnection.socket.getOutputStream());
							objectOutputStream.writeObject(new TransportObject(ServiceType.Service.search_friend,
									et_index.getText().toString().trim()));
							while (state == ServiceType.State.block) {
								Thread.sleep(1);
							}
							if (state == ServiceType.State.complete) {
								Toast.makeText(AddFriendActivity.this, "��ѯ���û�����", Toast.LENGTH_SHORT).show();
								Intent intent = new Intent(AddFriendActivity.this, SearchListActivity.class);
								startActivity(intent);
							} else {
								Toast.makeText(AddFriendActivity.this, "δ��ѯ���κν��", Toast.LENGTH_SHORT).show();
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						Looper.loop();
					}
				}).start();
			}
		});
	}
}
