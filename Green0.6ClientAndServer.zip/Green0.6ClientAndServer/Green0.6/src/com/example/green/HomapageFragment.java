package com.example.green;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

public class HomapageFragment extends Fragment {
	private Button bt_search;

	@SuppressLint("InflateParams")
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.homepage_fragment, null);
		InitView(view);
		return view;
	}

	public void InitView(View view) {
		bt_search = (Button) view.findViewById(R.id.button_search);
		bt_search.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				PopWindow popWindow = new PopWindow(getActivity());
				popWindow.showPopupWindow(v.findViewById(R.id.button_search));
			}
		});
	}
}