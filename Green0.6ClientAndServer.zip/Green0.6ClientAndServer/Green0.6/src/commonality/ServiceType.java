package commonality;

public interface ServiceType {
	public class Service {
		public static final int login = 1;
		public static final int regist = 2;
		public static final int get_friend_list = 3;
		public static final int return_friend_list = 4;
		public static final int log_out = 5;
		public static final int change = 6;
		public static final int search_friend = 7;
		public static final int add_friend = 8;
		public static final int agree_add_friend = 9;
		public static final int message = 10;
	}

	public class State {
		public static final int block = 100;
		public static final int error = 101;
		public static final int complete = 102;
	}
}
