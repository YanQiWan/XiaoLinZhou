package commonality;

@SuppressWarnings("serial")
public class TransportObject implements java.io.Serializable {
	private Object object;
	private int servicetype;
	private String getter;
	private String sender;
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public TransportObject(int servicetype, Object object) {
		this.object = object;
		this.servicetype = servicetype;
	}

	public String getGetter() {
		return getter;
	}

	public void setGetter(String getter) {
		this.getter = getter;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String setter) {
		this.sender = setter;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}

	public int getServicetype() {
		return servicetype;
	}

	public void setServicetype(int servicetype) {
		this.servicetype = servicetype;
	}
}
