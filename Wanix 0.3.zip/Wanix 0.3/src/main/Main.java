package main;

import java.util.*;

import processmanager.*;
import processmanager.Process;

public class Main {
	public static void main(String args[]) {
		PCB pcb1 = new PCB(0, 1, 10, "process1");
		List<ProcessEvent> events1 = new ArrayList<ProcessEvent>();
		events1.add(new NormalEvent(1));
		events1.add(new IOEvent());
		events1.add(new NormalEvent(5));
		Process p1 = new Process(pcb1, events1);
		ProcessControler.create(p1);
		PCB pcb2 = new PCB(0, 1, 5, "process2");
		List<ProcessEvent> events2 = new ArrayList<ProcessEvent>();
		events2.add(new NormalEvent(1));
		// events2.add(new NormalEvent(1));
		events2.add(new IOEvent());
		events2.add(new NormalEvent(2));
		Process p2 = new Process(pcb2, events2);
		ProcessControler.create(p2);

		new Thread(new ProcessControler()).start();
	}
}
