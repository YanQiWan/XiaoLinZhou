package processmanager;

import java.util.Scanner;

public class IOEvent extends BlockEvent {

	public IOEvent() {
		super();
	}

	private String condition = "";

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	@Override
	public void handleEvent() {
		System.out.println("Oops, I/O event in " + p.pcb.getName() + " just happened, please input the key...");
		try {
			ProcessControler.block();
		} catch (Exception e) {
			e.printStackTrace();
		}
		Scanner s = new Scanner(System.in);
		condition = s.next();
		String keystr = "1";
		while (!condition.equals(keystr)) {
			condition = s.next();
		}
		ProcessControler.wake(p.pcb.getId());

	}

}
