package processmanager;

public class ExceptionEvent extends BlockEvent {

	public ExceptionEvent() {
		super();
	}

	@Override
	public void handleEvent() {
		try {
			ProcessControler.remove();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
