package processmanager;

public class NormalEvent extends ProcessEvent {
	private long time;// ����ʱ��
	// private boolean flag = false;

	public long getTime() {
		return time;
	}

	@Override
	void handleEvent() throws Exception {
		if (time < ProcessControler.timeSlice) {
			// ProcessControler.currentTime+=time;
			p.pcb.setExecutedTime(p.pcb.getExecutedTime() + time);
			System.out.println("Process " + p.pcb.getName() + " running " + time + " seconds....");
			Thread.sleep(time * 1000);
			time = 0;
		} else {
			p.pcb.setExecutedTime(p.pcb.getExecutedTime() + ProcessControler.timeSlice);
			System.out.println("Process " + p.pcb.getName() + " running " + ProcessControler.timeSlice + " seconds....");
			time -= ProcessControler.timeSlice;
			Thread.sleep(ProcessControler.timeSlice * 1000);
			// ProcessControler.ready();
		}
	}

	public NormalEvent(long time) {
		super();
		this.time = time;
	}

}
