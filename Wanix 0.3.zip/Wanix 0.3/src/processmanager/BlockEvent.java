package processmanager;

public abstract class BlockEvent extends ProcessEvent {
	private boolean satisfied = false;

	public boolean isSatisfied() {
		return satisfied;
	}

	public void setSatisfied(boolean satisfied) {
		this.satisfied = satisfied;
	}

	void satisfy() {
		satisfied = true;
	}
	// public abstract void Event();

}
