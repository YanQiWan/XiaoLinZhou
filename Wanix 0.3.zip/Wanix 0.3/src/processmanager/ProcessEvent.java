package processmanager;

public abstract class ProcessEvent {
	protected Process p;

	public void setProcess(Process p) {
		this.p = p;
	}

	abstract void handleEvent() throws Exception;
}
