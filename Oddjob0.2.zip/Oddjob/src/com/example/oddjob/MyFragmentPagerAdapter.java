package com.example.oddjob;

import java.util.List;
import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

public class MyFragmentPagerAdapter extends FragmentPagerAdapter {
	TextView textView1;
	Context context;
	private List<Fragment> mFragments;
	private List<String> mTitles;
	private int[] mapId = { R.drawable.tab0, R.drawable.empty_tab, R.drawable.empty_tab };

	public MyFragmentPagerAdapter(FragmentManager fm, List<Fragment> mFragment, List<String> mTitles, Context context) {
		super(fm);
		this.mFragments = mFragment;
		this.mTitles = mTitles;
		this.context = context;
		// TODO Auto-generated constructor stub
	}

	@SuppressLint("InflateParams")
	@SuppressWarnings("deprecation")
	public View getTabView(int position) {
		View v = LayoutInflater.from(context).inflate(R.layout.bottom_bar_item, null);
		textView1 = (TextView) v.findViewById(R.id.item_text);
		textView1.setBackgroundResource(mapId[position]);
		textView1.setText(mTitles.get(position));
		if (position == 0) {
			textView1.setTextColor(v.getResources().getColor(R.color.colorSelected));
		}
		return v;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mTitles.size();
	}

	@Override
	public Fragment getItem(int arg0) {
		// TODO Auto-generated method stub
		return mFragments.get(arg0);
	}

	@Override
	public CharSequence getPageTitle(int position) {
		return mTitles.get(position);
	}
}
