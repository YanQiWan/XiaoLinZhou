package com.example.oddjob;

import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import com.example.library.SysApplication;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.design.widget.TabLayout.Tab;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends FragmentActivity {

	// TabLayout
	private TabLayout mTabLayout;
	// ViewPager
	private ViewPager mViewPager;
	// Title
	private List<String> mTitle;
	// Fragment
	private List<Fragment> mFragment;
	public static File database;// ���ݿ��ļ�

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// this.requestWindowFeature(Window.FEATURE_NO_TITLE);//ȥ��������
		SysApplication.getInstance().addActivity(this);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
				| WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		setContentView(R.layout.activity_main);
		initData();
		initView();
		// database=initdatabase();
	}

	/*
	 * ��ʼ������
	 */
	private void initData() {

		mTitle = new ArrayList<String>();
		mTitle.add("�� ��");
		mTitle.add("�� ��");
		mTitle.add("�� ��");

		mFragment = new ArrayList<Fragment>();
		mFragment.add(new DeliverFragment());
		mFragment.add(new ReceiveFragment());
		mFragment.add(new UserFragment());
		// DatabaseQuery.CollegeMkdirs();//���������ļ���Ŀ¼
	}

	/*
	 * ��ʼ��view
	 */
	private void initView() {
		mTabLayout = (TabLayout) findViewById(R.id.mTabLayout);
		mViewPager = (ViewPager) findViewById(R.id.mViewPager);

		mViewPager.setOffscreenPageLimit(mTabLayout.getTabCount());

		// mViewPager
		mViewPager.addOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				mTabLayout.getTabAt(arg0).select();
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub

			}
		});

		// ����������
		MyFragmentPagerAdapter myFragmentPagerAdapter = new MyFragmentPagerAdapter(getSupportFragmentManager(),
				mFragment, mTitle, this);
		mViewPager.setAdapter(myFragmentPagerAdapter);
		mTabLayout.setupWithViewPager(mViewPager);
		for (int i = 0; i < mTabLayout.getTabCount(); i++) {
			mTabLayout.getTabAt(i).setCustomView(myFragmentPagerAdapter.getTabView(i));
		}
		mTabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

			@SuppressWarnings("deprecation")
			@Override
			public void onTabUnselected(Tab tab) {
				// TODO Auto-generated method stub
				switch (tab.getPosition()) {
				case 0:
					tab.getCustomView().findViewById(R.id.item_text).setBackgroundResource(R.drawable.empty_tab);
					break;
				case 1:
					tab.getCustomView().findViewById(R.id.item_text).setBackgroundResource(R.drawable.empty_tab);
					break;
				case 2:
					tab.getCustomView().findViewById(R.id.item_text).setBackgroundResource(R.drawable.empty_tab);
					break;
				}
				TextView textView = (TextView) tab.getCustomView().findViewById(R.id.item_text);
				textView.setTextColor(getResources().getColor(R.color.colorAccent));
			}

			@SuppressWarnings("deprecation")
			@Override
			public void onTabSelected(Tab tab) {
				// TODO Auto-generated method stub
				switch (tab.getPosition()) {
				case 0:
					tab.getCustomView().findViewById(R.id.item_text).setBackgroundResource(R.drawable.tab0);
					break;
				case 1:
					tab.getCustomView().findViewById(R.id.item_text).setBackgroundResource(R.drawable.tab1);
					break;
				case 2:
					tab.getCustomView().findViewById(R.id.item_text).setBackgroundResource(R.drawable.tab2);
					break;
				}
				TextView textView = (TextView) tab.getCustomView().findViewById(R.id.item_text);
				textView.setTextColor(getResources().getColor(R.color.colorSelected));
				mViewPager.setCurrentItem(tab.getPosition());
			}

			@Override
			public void onTabReselected(Tab arg0) {
				// TODO Auto-generated method stub

			}
		});
		mViewPager.setCurrentItem(0);
		mTabLayout.getTabAt(0).select();
	}

	double exitTime = 0;

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
			if ((System.currentTimeMillis() - exitTime) > 2000) // System.currentTimeMillis()���ۺ�ʱ���ã��϶�����2000
			{
				Toast.makeText(getApplicationContext(), "�ٰ�һ���˳�����", Toast.LENGTH_SHORT).show();
				exitTime = System.currentTimeMillis();
			} else {
				/*
				 * try { ObjectOutputStream objectOutputStream = new
				 * ObjectOutputStream(
				 * InternetConnection.socket.getOutputStream()); TransportObject
				 * transportObject = new
				 * TransportObject(ServiceType.Service.log_out, null);
				 * transportObject.setSender(LoginActivity.login_user.
				 * getPhoneNumber());
				 * objectOutputStream.writeObject(transportObject); } catch
				 * (IOException e) { // TODO Auto-generated catch block
				 * e.printStackTrace(); }
				 */
				SysApplication.getInstance().exit();
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	// �����ݿ���ص��ֻ���
	/*
	 * private File initdatabase() { File file=getDatabasePath("school.db");
	 * if(!file.exists()) { file.getParentFile().mkdirs(); } else { return file;
	 * } BufferedInputStream bufferedInputStream = null; BufferedOutputStream
	 * bufferedOutputStream=null; try { bufferedInputStream=new
	 * BufferedInputStream(getAssets().open("school.db"));
	 * bufferedOutputStream=new BufferedOutputStream(new
	 * FileOutputStream(file)); byte[] buffer=new byte[8192]; int len=0;
	 * while((len=bufferedInputStream.read(buffer))!=-1) {
	 * bufferedOutputStream.write(buffer,0,len); } bufferedOutputStream.flush();
	 * return file; } catch (IOException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); }finally{ try { if(bufferedInputStream!=null)
	 * bufferedInputStream.close(); if(bufferedOutputStream!=null)
	 * bufferedOutputStream.close(); } catch (IOException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } } return null; }
	 */

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
