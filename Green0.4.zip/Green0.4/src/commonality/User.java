package commonality;

import java.util.List;

@SuppressWarnings("serial")
public class User implements java.io.Serializable {
	private String PhoneNumber;
	private String Passwd;
	private int score;
	private String NickName;
	private int age;
	private byte[] headimage;
	private List<User> FriendList;
	private int getter;


	public int getGetter() {
		return getter;
	}

	public void setGetter(int getter) {
		this.getter = getter;
	}

	public List<User> getFriendList() {
		return FriendList;
	}

	public void setFriendList(List<User> friendList) {
		FriendList = friendList;
	}

	public byte[] getHeadimage() {
		return headimage;
	}

	public void setHeadimage(byte[] headimage) {
		this.headimage = headimage;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getPasswd() {
		return Passwd;
	}

	public void setPasswd(String passwd) {
		Passwd = passwd;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getNickName() {
		return NickName;
	}

	public void setNickName(String nickName) {
		NickName = nickName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	public User(){}

	public User(String number, String Passwd) {
		this.PhoneNumber = number;
		this.Passwd = Passwd;
	}

	public User(String number, String Passwd, String NickName, int age) {
		this(number, Passwd);
		this.NickName = NickName;
		this.age = age;
	}
}
