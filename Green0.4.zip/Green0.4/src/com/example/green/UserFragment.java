package com.example.green;

import com.example.library.CircleImageView;
import com.example.library.MacroDefinition;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import connectiontools.InternetConnection;

public class UserFragment extends Fragment {
	private TextView tv_NickName;
	private TextView tv_Age;
	private TextView tv_PhoneNumber;
	private TextView tv_Score;
	private CircleImageView civ_head;
	private Button bt_exit;

	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.personal_fragment, null);
		initView(view);
		return view;
	}

	private void initView(View view) {
		tv_NickName = (TextView) view.findViewById(R.id.tv_NickName);
		tv_Age = (TextView) view.findViewById(R.id.tv_Age);
		tv_PhoneNumber = (TextView) view.findViewById(R.id.tv_PhoneNumber);
		tv_Score = (TextView) view.findViewById(R.id.tv_Score);
		civ_head = (CircleImageView) view.findViewById(R.id.civ_HeadIamge);
		tv_NickName.setText(LoginActivity.login_user.getNickName());
		tv_Age.setText(LoginActivity.login_user.getAge() + "");
		tv_PhoneNumber.setText(LoginActivity.login_user.getPhoneNumber());
		tv_Score.setText(LoginActivity.login_user.getScore() + "");
		if (LoginActivity.login_user.getHeadimage() != null) {
			civ_head.setImageBitmap(MacroDefinition.getPicFromBytes(LoginActivity.login_user.getHeadimage(),
					new BitmapFactory.Options()));
		}
		bt_exit = (Button) view.findViewById(R.id.bt_exit);
		bt_exit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(getContext(), LoginActivity.class);
				InternetConnection.socket = null;
				startActivity(intent);
			}
		});
	}
}
