package com.example.green;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.example.library.MacroDefinition;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import commonality.User;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;

public class FriendFragment extends Fragment {
	private ListView listView;
	// CalThread calThread;

	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.friend_fragment, null);
		listView = (ListView) view.findViewById(R.id.list);
		inflateListView(LoginActivity.login_user.getFriendList());
		return view;
	}

	// 359372862
	public void inflateListView(List<User> friendList) {
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < friendList.size(); i++) {

			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put("Rank", i);
			listItem.put("HeadImage",
					MacroDefinition.getPicFromBytes(friendList.get(i).getHeadimage(), new BitmapFactory.Options()));
			listItem.put("NickName", friendList.get(i).getNickName());
			listItem.put("Score", friendList.get(i).getScore());
			listItem.put("Medal", R.drawable.ic_launcher);
			listItems.add(listItem);
			//
		}
		SimpleAdapter simpleAdapter = new SimpleAdapter(this.getActivity(), listItems, R.layout.friend_list,
				new String[] { "Rank", "HeadImage", "NickName", "Score", "Medal" },
				new int[] { R.id.tv_rank, R.id.civ_HeadIamge, R.id.tv_name, R.id.tv_score, R.id.iv_medal });
		listView.setAdapter(simpleAdapter);
		simpleAdapter.setViewBinder(new SimpleAdapter.ViewBinder() {
			@Override
			public boolean setViewValue(View view, Object data, String textRepresentation) {
				// TODO Auto-generated method stub
				if (view instanceof ImageView && data instanceof Bitmap) {
					ImageView iv = (ImageView) view;
					iv.setImageBitmap((Bitmap) data);
					return true;
				} else {
					return false;
				}
			}
		});
		listView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

			}
		});
	}

}
