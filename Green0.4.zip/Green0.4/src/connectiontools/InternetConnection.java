package connectiontools;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import commonality.*;

public class InternetConnection extends Thread {
	public static Socket socket = null;
	private static InternetConnection internetConnection = null;

	private InternetConnection() throws Exception {
	}

	public static InternetConnection getInstance() throws Exception {
		if (internetConnection == null)
			internetConnection = new InternetConnection();
		return internetConnection;
	}

	public void run() {
		while (true) {
			try {
				ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
				TransportObject m = (TransportObject) in.readObject();
			} catch (Exception e) {
			}
		}
	}

	public User MessageTransmit(User user) {
		try {
			Socket s = new Socket("101.200.38.1", 7777);
			ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
			out.writeObject(new TransportObject(ServiceType.login, user));
			System.out.println(user.getPhoneNumber() + user.getPasswd() + "aaaaa\n\n\n");
			ObjectInputStream in = new ObjectInputStream(s.getInputStream());
			System.out.print("aaaaa\n\n\n");
			User login_user = (User) in.readObject();
			if (login_user != null) {
				System.out.println("��½�ɹ�");
				socket = s;
				start();
			} else {
				System.out.println("��½ʧ��");
			}
			return login_user;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public boolean RegistInformation(User changed_user) {
		boolean flag = false;
		try {
			@SuppressWarnings("resource")
			Socket s = new Socket("101.200.38.1", 7777);
			ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
			out.writeObject(new TransportObject(ServiceType.regist, changed_user));
			ObjectInputStream in = new ObjectInputStream(s.getInputStream());
			flag = (Boolean) in.readObject();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
}
