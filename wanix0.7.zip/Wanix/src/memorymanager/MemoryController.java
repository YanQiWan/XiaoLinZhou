package memorymanager;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

import processmanager.Process;

public class MemoryController {
	public static final long MEMORYSIZE = 2000;
	public static List<PartitionItem> partition_table = new CopyOnWriteArrayList<PartitionItem>();
	static{
		PartitionItem memory = new PartitionItem();
		memory.setSize(MEMORYSIZE);
		memory.setStartAddress(0);
		partition_table.add(memory);
	}
	static long remaintotal = MEMORYSIZE ;
	public static void allocation(Process p){
		long psize = p.pcb.getSize();
		ListIterator<PartitionItem> it = partition_table.listIterator();
		while(it.hasNext()){
			int index = it.nextIndex() ;
			PartitionItem curitem = it.next();
			if(curitem.isEmpty()&&curitem.getSize()>=psize){
				curitem.setP(p);
				remaintotal -= psize;
				long remain = curitem.getSize() - psize;
				if(remain != 0){	
					curitem.setSize(psize);
					PartitionItem newItem = new PartitionItem();
					newItem.setSize(remain);
					newItem.setStartAddress(curitem.getStartAddress()+psize);
					partition_table.add(index+1, newItem);
				}
				break;
			}
			else if(remaintotal>=psize){
				
			}
			else{
				
			}
		}
	}
	public static void release(Process p){
		
	}
}
