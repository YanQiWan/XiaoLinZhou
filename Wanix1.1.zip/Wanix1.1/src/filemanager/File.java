package filemanager;

public class File {
	private Inode inode;
	public static int count=0;
	public Inode getInode() {
		return inode;
	}

	public void setInodeID() {
		inode.setId(count);
		count++;
	}
	
}
