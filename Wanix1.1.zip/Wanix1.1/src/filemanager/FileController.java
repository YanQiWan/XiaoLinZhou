package filemanager;

import java.util.ArrayList;
import java.util.List;

import processmanager.Process;

public class FileController {
	private static FileController fileController = null;
	private static Directory root;
	private static Directory current_dir;
	private Disk disk = null;
	public static final int  DEFAULT = DiskBlock.SIZE;
	private FileController(Disk disk) {
		this.disk = disk;
	}

	public static FileController GetFileController(Disk disk) {
		if (fileController == null)
			fileController = new FileController(disk);
		return fileController;
	}
	public boolean create(Process p, String name, Directory dir,FileType t) throws Exception{
		
		if (dir == null) {
			dir = p.pcb.getDir();
		}
		String className = null;
		if(t.compareTo(FileType.DOCUMENT)==0){
			className = "Document";
		}
		else if(t.compareTo(FileType.DIRECTORY)==0){
			className = "Directory";
		}
		File newFile =(File) Class.forName(className).newInstance();
		boolean flag;
		if(flag=diskAllocate(DEFAULT, newFile)){
			newFile.getInode().setTime(System.currentTimeMillis());
			newFile.getInode().setType(t);
			newFile.getInode().setFilename(name);
			newFile.setInodeID();
			newFile.getInode().setParent(dir);
			newFile.getInode().setPermission(p.pcb.getPermission());
			dir.files.put(name, newFile);
		}

		return flag;
		
	}
//	public boolean touch(Process p, String name, Directory dir) {//name����׺��
//		if (dir == null) {
//			dir = p.pcb.getDir();
//		}
//
//		Document newdoc = new Document();
//		boolean flag;
//		if(flag=diskAllocate(DEFAULT, newdoc)){
//			newdoc.getInode().setTime(System.currentTimeMillis());
//			newdoc.getInode().setType(FileType.DOCUMENT);
//			newdoc.getInode().setFilename(name);
//			newdoc.setInodeID();
//			newdoc.getInode().setParent(dir);
//			newdoc.getInode().setPermission(p.pcb.getPermission());
//			dir.files.put(name, newdoc);
//		}
//
//		return flag;
//	}
//
//	public boolean mkdir(Process p, String name, Directory dir) {
//		if (dir == null) {
//			dir = p.pcb.getDir();
//		}
//
//		Directory newdir = new Directory();
//		boolean flag;
//		if(flag=diskAllocate(DEFAULT, newdir)){
//			newdir.getInode().setTime(System.currentTimeMillis());
//			newdir.getInode().setType(FileType.DIRECTORY);
//			newdir.getInode().setFilename(name);
//			newdir.setInodeID();
//			newdir.getInode().setParent(dir);
//			newdir.getInode().setPermission(p.pcb.getPermission());
//			dir.files.put(name, newdir);
//		}
//		return flag;
//	}
	
	public boolean remove(Process p, Document doc) {
		boolean flag;
		if(p.pcb.getPermission().compareTo(doc.getInode().getPermission())>=0)
		{
			diskRelease(doc);
		}
		else
			flag=false;

		return flag;
	}

	public boolean rmdir(Process p, String name, Directory dir) {
		if (dir == null) {
			dir = p.pcb.getDir();
		}

		Directory newdir = new Directory();
		boolean flag;
		if(flag=diskAllocate(DEFAULT, newdir)){
			newdir.getInode().setTime(System.currentTimeMillis());
			newdir.getInode().setType(FileType.DIRECTORY);
			newdir.getInode().setFilename(name);
			newdir.setInodeID();
			newdir.getInode().setParent(dir);
			newdir.getInode().setPermission(p.pcb.getPermission());
			dir.files.put(name, newdir);
		}
		return flag;
	}
	@SuppressWarnings("static-access")
	public boolean diskAllocate(int size, File file) {
		int blocknum = (int) (Math.ceil((double) size / (double) DiskBlock.SIZE));		
		if (disk.getRemainnum() >= blocknum) {
			file.getInode().setBlock_num(blocknum);
			disk.setRemainnum(disk.getRemainnum() - blocknum);
			for (DiskBlock db : disk.getBlocks()) {
				if (db.isAvailable()) {
					blocknum--;
					db.setAvailable(false);
					file.getInode().getDisk_block_id().add(db.getId());
					if (blocknum == 0)
						break;
				}
			}
			return true;
		} else
			return false;
	}
	public boolean diskRelease(File file){
		List<Integer> disk_block_id=file.getInode().getDisk_block_id();
		for(Integer i:disk_block_id){
			disk.getBlocks()[i].setAvailable(true);
		}
		disk.setRemainnum(disk.getRemainnum()+disk_block_id.size());
		file.getInode().setBlock_num(0);
		
		return true;
	}
}
