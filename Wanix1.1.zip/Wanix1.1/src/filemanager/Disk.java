package filemanager;

public class Disk {
	private int blocknum;
	private static DiskBlock blocks[];
	private int remainnum; 
	
	Disk(int blocknum){
		this.blocknum=blocknum;
		remainnum=blocknum;
		blocks=new DiskBlock[this.blocknum];
		for(int i=0;i<this.blocknum;i++){
			blocks[i]=new DiskBlock(i);
		}
	}
	
	public int getRemainnum() {
		return remainnum;
	}

	public void setRemainnum(int remainnum) {
		this.remainnum = remainnum;
	}
	
	public int getBlocknum() {
		return blocknum;
	}

	public static DiskBlock[] getBlocks() {
		return blocks;
	}
}
