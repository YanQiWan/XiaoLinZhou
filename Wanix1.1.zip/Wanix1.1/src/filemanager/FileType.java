package filemanager;

public enum FileType {
	DOCUMENT,DIRECTORY;
}
