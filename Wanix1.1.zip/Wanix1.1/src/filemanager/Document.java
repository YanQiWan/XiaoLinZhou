package filemanager;

public class Document extends File {
	
}
